
let ti = 0; // time variable
var s = function(p){

p.setup = function() {
  p.createCanvas(p.windowHeight,100);
  p.noStroke();
  p.fill(40, 200, 40);
}

p.draw = function() {
  p.background(10, 10); // translucent background (creates trails)

  // make a x and y grid of ellipses
    p.for (let x = 0; x <= width; x = x + 30){
    p.for (let y = 0; y <= height; y = y + 30){
      // starting point of each circle depends on mouse position
      p.let xAngle = map(mouseX/5, 0, width, -4 * PI, 4 * PI, true);
      p.let yAngle = map(mouseY/5, 0, height, -4 * PI, 4 * PI, true);
      // and also varies based on the particle's location
      p.let angle = xAngle * (x / width) + yAngle * (y / height);

      // each particle moves in a circle
      p.let myX = x + 20 * cos(2 * PI * t + angle);
      p.let myY = y + 20 * sin(2 * PI * t + angle);

      p.ellipse(myX, myY, 10); // draw particle
    }
  }
  ti = ti + 0.006; // update time
}
}
var myp5 = new p5(s,'c1');

//sketch 2
var t = function(p){


p.windowResized = function(){
	p.resizeCanvas(p.windowWidth,p.windowHeight);
}
p.setup = function (){
	p.canvas = p.createCanvas(p.windowWidth,p.windowHeight);
	//canvas.position(0,0);
	//p.canvas.style('z-index','-1');
}
p.draw = function(){
	p.fill(40,200,40);
	p.ellipse(p.mouseX,p.mouseY,50);
}
}
var myp5 = new p5(t,'c2');
